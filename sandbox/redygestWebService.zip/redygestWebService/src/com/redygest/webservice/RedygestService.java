package com.redygest.webservice;

import com.redygest.webservice.model.Results;

public interface RedygestService {
	public Results getQueryResults(String hw1, String r, String hw2);
}
