Carrot2 Java API
----------------

Carrot2 Java API lets you embed Carrot2 clustering in your Java software.
The API requires a Java Development Kit (JDK) version 1.6.0 or later. Please
see the examples/ directory for some sample code.

Carrot2 Java API Javadocs available at:
http://download.carrot2.org/stable/javadoc

For more information, please refer to Carrot2 Manual:
http://download.carrot2.org/stable/manual



Build information
-----------------

Build version : 3.5.0-dev
Build number  : C2HEAD-CORE-761
Build time    : 2010-11-09 17:13:14
Built by      : tomcat
Build revision: 4645
